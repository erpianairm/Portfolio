<div class="flex px-6 pt-6 flex-col gap-y-1">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\irmae\sites\sticky\resources\views/components/card/header.blade.php ENDPATH**/ ?>