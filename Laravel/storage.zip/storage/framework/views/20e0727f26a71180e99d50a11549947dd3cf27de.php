<textarea <?php echo e($attributes->merge(['class' => 'w-full border-stone-600 bg-yellow-200 rounded-md shadow-sm'])); ?>>

    <?php echo e($slot); ?>

</textarea><?php /**PATH C:\Users\irmae\sites\sticky\resources\views/components/textarea.blade.php ENDPATH**/ ?>