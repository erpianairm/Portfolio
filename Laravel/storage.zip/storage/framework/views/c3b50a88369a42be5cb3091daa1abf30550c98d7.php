<div>
    <!-- Very little is needed to make a happy life. - Marcus Aurelius -->
</div><?php /**PATH C:\Users\irmae\sites\sticky\resources\views/components/footer.blade.php ENDPATH**/ ?>