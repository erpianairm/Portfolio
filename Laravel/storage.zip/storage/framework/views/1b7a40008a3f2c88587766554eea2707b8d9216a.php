<div class="text-yellow-500 text-sm">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\irmae\sites\sticky\resources\views/components/card/description.blade.php ENDPATH**/ ?>