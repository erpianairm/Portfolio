<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
           <?php echo e($slot); ?>

        </div><?php /**PATH C:\Users\irmae\sites\sticky\resources\views/components/container.blade.php ENDPATH**/ ?>