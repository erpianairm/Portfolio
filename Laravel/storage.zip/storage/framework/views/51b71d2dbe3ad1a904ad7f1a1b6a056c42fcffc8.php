<div <?php echo e($attributes->merge([
    'class' => "bg-stone-100 shadow-sm border border-yellow-500 rounded-lg"
])); ?>>
<?php echo e($slot); ?>

</div>
    <?php /**PATH C:\Users\irmae\sites\sticky\resources\views/components/card/index.blade.php ENDPATH**/ ?>