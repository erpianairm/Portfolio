<footer class="bg-gradient-to-r from-yellow-200 to-amber-500 text-stone-600 py-10 ">
    <div class="container mx-auto text-center font-medium">
        <?php echo e(config('app.name')); ?> &copy; 2022 - <?php echo e(now()->format('Y')); ?>

    </div>
</footer>
<?php /**PATH C:\Users\irmae\sites\sticky\resources\views/layouts/footer.blade.php ENDPATH**/ ?>