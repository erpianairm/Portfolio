<div class="p-6">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\irmae\sites\sticky\resources\views/components/card/content.blade.php ENDPATH**/ ?>