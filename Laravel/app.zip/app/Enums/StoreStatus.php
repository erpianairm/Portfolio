<?php

namespace App\Enums;

class StoreStatus
{
    public const PENDING = 'pending';
    public const ACTIVE = 'active';
}
