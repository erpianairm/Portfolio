<div class="p-6">
    {{ $slot }}
</div>