<div class="text-yellow-500 text-sm">
    {{ $slot }}
</div>