<div {{ $attributes->merge([
    'class' => "bg-stone-100 shadow-sm border border-yellow-500 rounded-lg"
]) }}>
{{ $slot }}
</div>
    