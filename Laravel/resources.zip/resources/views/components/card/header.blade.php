<div class="flex px-6 pt-6 flex-col gap-y-1">
    {{ $slot }}
</div>