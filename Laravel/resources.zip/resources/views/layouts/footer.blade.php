<footer class="bg-gradient-to-r from-yellow-200 to-amber-500 text-stone-600 py-10 ">
    <div class="container mx-auto text-center font-medium">
        {{ config('app.name') }} &copy; 2022 - {{ now()->format('Y') }}
    </div>
</footer>
